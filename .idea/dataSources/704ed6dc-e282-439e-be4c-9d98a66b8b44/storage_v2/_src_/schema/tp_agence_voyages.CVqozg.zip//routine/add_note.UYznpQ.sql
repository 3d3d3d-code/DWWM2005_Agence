create
    definer = root@localhost procedure add_note(IN trip_code_in int, IN service_code_in int, IN client_id_in int,
                                                IN service_score_in tinyint)
BEGIN 

	DECLARE service_count INT;
    DECLARE note_exists INT;
    DECLARE strip_consume INT;

	SELECT COUNT(*) INTO service_count 
    FROM consumes WHERE client_id=client_id_in AND service_code=service_code_in;
	
    SELECT COUNT(*) INTO note_exists 
    FROM notes WHERE client_id=client_id_in AND service_code=service_code_in;
    
    SELECT COUNT(*) INTO strip_consume
	FROM consumes WHERE client_id=client_id_in;
    
    IF service_count <> 0 AND note_exists = 0 AND strip_consume > 0
    THEN 
    
		INSERT INTO notes 
		(trip_code, service_code, client_id, service_score) 
		VALUES 
		(trip_code_in, service_code_in, client_id_in, service_score_in);
        
        SELECT * FROM notes WHERE client_id=client_id_in AND trip_code=trip_code_in AND service_code=service_code_in;
	
    ELSE 
    
		SELECT "Impossible" as Erreur, "T'as fait nimp" as raison;
        
    END IF;
    
    
    
    
END;

